import json,os,re,subprocess,sys
from pathlib import Path
sys.path.insert(0,'scripts')
from phase1_capture import request_bytes
root=Path.cwd();out=root/'target/pr56-review'
up=root/'upstream/tsc/internal/ast'
inputs=root/'tools/phase1/syntax/ast-generated'
request=json.loads((inputs/'requests.json').read_bytes())
op='tsc/internal/ast/visitor.go:NodeVisitor.liftToBlock'
request['requests']=[r for r in request['requests'] if op in r.get('operations',[])]
(out/'requests.json').write_bytes(request_bytes(request))
visitor=(up/'visitor.go').read_text()
visitor,n=re.subn(r'func \(v \*NodeVisitor\) liftToBlock\(node \*Statement\) \*Statement \{.*?\n\}',
                 'func (v *NodeVisitor) liftToBlock(node *Statement) *Statement { return node }',visitor,flags=re.S)
assert n==1
(out/'visitor_identity.go').write_text(visitor)
replace={str(up/'visitor.go'):str(out/'visitor_identity.go')}
for source in ['probe_test.go','predicates_test.go','shapes_test.go','shapes_runtime_test.go']:
 replace[str(up/('review_'+source))]=str(inputs/source)
(out/'overlay.json').write_text(json.dumps({'Replace':replace}))
env=dict(os.environ,GOTOOLCHAIN='local',S08_REQUESTS=str(out/'requests.json'),S08_OUTPUT=str(out/'identity-observations.json'))
p=subprocess.run(['go','test','-mod=readonly','-overlay',str(out/'overlay.json'),'./internal/ast','-run','^TestPhase1GeneratedAST$','-count=1','-timeout=120s'],cwd=root/'upstream/tsc',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=150)
print(p.stdout);p.check_returncode()
native=json.loads((out/'syntax-capture/native/generated_ast/observations.json').read_bytes())
expected={r['case']:r for r in native['observations']}
actual=json.loads((out/'identity-observations.json').read_bytes())['observations']
assert len(actual)==len(request['requests'])
diff=[r['case'] for r in actual if r!=expected[r['case']]]
print(json.dumps({'mutant':'liftToBlock returns its input unchanged','rows':len(actual),'different':diff},indent=2))
